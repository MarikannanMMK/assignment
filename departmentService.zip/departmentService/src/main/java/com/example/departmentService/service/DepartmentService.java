package com.example.departmentService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.departmentService.entity.Department;
import com.example.departmentService.repository.DepartmentRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DepartmentService {
	
	@Autowired
	private DepartmentRepository departmentrepository;

	public Department saveDepartment(Department department) {
		
		log.info("Inside saveDepartment method of departmentService");

		return departmentrepository.save(department);
	}

	public Department findDepartmentById(int departmentId) {
		log.info("Inside findDepartmentById method of departmentService");

		return departmentrepository.findByDepartmentId(departmentId);
	}

}
